import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  Image,
  Button,
  Pressable,
  TouchableOpacity,
} from 'react-native';
import vs_blue from './assets/vs_blue.png';
import star from './assets/star.png';

export default function Screen1({ route, navigation }) {
  const [colorImg, setColorImg] = useState(vs_blue);

 useEffect(() => {
    if (route.params?.colorImg) {
      setColorImg(route.params.colorImg);
    }
  }, [route.params?.colorImg]);

  return (
    <View style={styles.container}>
      <View>
        <Image source={colorImg} style={{ height: 300, width: 250 }} />
      </View>

      <View>
        <Text>Điện thoại Vsmart Joy3 - Hàng chính hãng</Text>
      </View>

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 10,
        }}>
        <View style={{ flexDirection: 'row' }}>
          <Image source={star} style={{ height: 30, width: 30 }} />
          <Image source={star} style={{ height: 30, width: 30 }} />
          <Image source={star} style={{ height: 30, width: 30 }} />
          <Image source={star} style={{ height: 30, width: 30 }} />
          <Image source={star} style={{ height: 30, width: 30 }} />
        </View>
        <View>
          <Text>(xem 828 đánh giá)</Text>
        </View>
      </View>

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'flex-start',
          alignItems: 'center',
          gap: 10,
        }}>
        <View>
          <Text>1.790.000 đ</Text>
        </View>
        <View>
          <Text style={styles.strikethrough}>1.790.000 đ</Text>
        </View>
      </View>

      <View style={{ flexDirection: 'row', gap: 30 }}>
        <Text style={{ color: 'red', fontSize: 12, fontWeight: 600 }}>
          Ở ĐÂU RẺ HƠN HOÀN TIỀN
        </Text>
        <Text>?</Text>
      </View>

      <Pressable
        style={{
          backgroundColor: 'white',
          height: 34,
          width: 220,
          borderColor: 'gray',
          borderWidth: 1,
          borderRadius: 10,
          justifyContent: 'center',
          alignItems: 'center',
        }}
        onPress={() => navigation.navigate('screen2')}>
        <Text>4 MÀU - CHỌN MÀU ></Text>
      </Pressable>

      <TouchableOpacity
        style={{
          width: 300,
          borderRadius: 10,
          borderWidth: 1,
          height: 34,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'red',
          marginTop: 50,
        }}>
        <Text style={{ color: 'white', fontSize: 20, fontWeight: 450 }}>
          Chọn mua
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
    alignItems: 'center',
    gap: 10,
  },
  // gạch ngang giá tiền
  strikethrough: {
    textDecorationLine: 'line-through',
    fontSize: 20,
    color: '#808080', // Bạn có thể thay đổi màu sắc theo ý muốn
  },
});
