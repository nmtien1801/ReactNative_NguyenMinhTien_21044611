import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  Image,
  Button,
  TouchableOpacity,
} from 'react-native';
import vs_blue from './assets/vs_blue.png';
import vs_red from './assets/vs_red.png';
import vs_sliver from './assets/vs_silver.png';
import vs_black from './assets/vs_black.png';

const setImg = [
  {
    blue: vs_blue,
    red: vs_red,
    black: vs_black,
    white: vs_sliver,
  },
];

export default function Screen2({ navigation }) {
  const [colorImg, setColorImg] = useState(setImg[0].blue);

  return (
    <View style={styles.container}>
      <View
        style={{
          flexDirection: 'row',
          backgroundColor: 'white',
          borderWidth: 1,
          borderStyle: 'solid',
          borderColor: 'red',
          padding: 8,
          gap: 10,
        }}>
        <Image source={colorImg} style={{ height: 132, width: 112 }} />

        <Text>Điện Thoại Vsmart Joy 3 Hàng chính hãng</Text>
      </View>

      <View
        style={{
          backgroundColor: '#C4C4C4',
          width: 398,
          justifyContent: 'center',
          alignItems: 'center',
          gap: 20,
          borderWidth: 1,
          borderColor: 'blue',
        }}>
        <Text>Chọn một màu bên dưới: </Text>
        <TouchableOpacity
          style={{
            backgroundColor: '#C5F1FB',
            width: 75,
            height: 70,
          }}
          onPress={() => setColorImg(setImg[0].blue)}></TouchableOpacity>
        <TouchableOpacity
          style={{
            backgroundColor: '#F30D0D',
            width: 75,
            height: 70,
          }}
          onPress={() => setColorImg(setImg[0].red)}></TouchableOpacity>
        <TouchableOpacity
          style={{
            backgroundColor: '#000000',
            width: 75,
            height: 70,
          }}
          onPress={() => setColorImg(setImg[0].black)}></TouchableOpacity>
        <TouchableOpacity
          style={{
            backgroundColor: 'white',
            width: 75,
            height: 70,
          }}
          onPress={() => setColorImg(setImg[0].white)}></TouchableOpacity>

        <TouchableOpacity
          style={{
            backgroundColor: '#1952E294',
            width: 270,
            height: 44,
            borderColor: 'red',
            borderWidth: 1,
            borderRadius: 10,
            justifyContent: 'center',
            alignItems: 'center',
          }}
            onPress={() => navigation.navigate('screen1', { colorImg })}>
          <Text style={{ fontSize: 20, fontWeight: 420 }}>Xong</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
    alignItems: 'center',
    height: 640,
  },
});
