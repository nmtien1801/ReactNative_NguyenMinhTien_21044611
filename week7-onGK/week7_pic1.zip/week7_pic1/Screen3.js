import React, { useState, useEffect } from 'react';
import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  FlatList,
} from 'react-native';
import input from './assets/input.png';
import note from './assets/note.png';

export default function Screen3({ route, navigation }) {
  const [text, setText] = useState('');

  return (
    <View style={styles.container}>
      <View>
        <Text style={{ fontSize: 28, fontWeight: 600, color: 'black' }}>
          ADD YOUR JOB
        </Text>
      </View>
      <View
        style={{
          flexDirection: 'row',
          gap: 10,
          padding: 5,
          borderWidth: 1,
          width: 200,
          borderRadius: 5,
          borderColor: '#9095A0',
        }}>
        <Image source={input} />
        <TextInput
          value={text}
          placeholder="Input your job"
          placeholderTextColor="black"
          onChangeText={setText}
        />
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: '#00BDD6',
          width: 100,
          padding: 10,
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 10,
        }}
        onPress={() => {
          navigation.navigate('screen2', { text });
        }}>
        <Text style={{ fontSize: 15, color: 'white' }}>FINISH -></Text>
      </TouchableOpacity>

      <View>
        <Image source={note} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 8,
    alignItems: 'center',
    gap: 30,
  },
});
