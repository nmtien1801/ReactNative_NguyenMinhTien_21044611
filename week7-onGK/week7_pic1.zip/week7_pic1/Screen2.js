import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  FlatList,
} from 'react-native';
import React, { useState, useEffect } from 'react';

import search from './assets/search.png';
import pen from './assets/pen.png';
import check from './assets/check.png';

import ModalEdit from './ModalEdit';

const dataApi = [
  { id: 1, value: 'to check email' },
  { id: 2, value: 'UI task web page' },
  { id: 3, value: 'learn javascript basic' },
  { id: 4, value: 'learn HTML advance' },
  { id: 5, value: 'medical app UI' },
  { id: 6, value: 'learn java' },
];

export default function Screen2({ navigation, route }) {
  const [data, setData] = useState([]);
  const [showEdit, setShowEdit] = useState(false);
  const [idUpdate, setIdupdate] = useState();


  const remove = async (id) => {
    // const newArr = data.filter((item) => item.id !== id);
    // setData(newArr);

    let res = await fetch(
      `https://6708715e8e86a8d9e42eecda.mockapi.io/api/job/${id}`,
      { method: 'DELETE' }
    );

    if (res.ok) {
      alert('delete success');
      fetchData();
    }
  };

  const update = async (id, data) => {
    let res = await fetch(
      `https://6708715e8e86a8d9e42eecda.mockapi.io/api/job/${id}`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      }
    );
    
    if(res.ok) alert('update success')
    fetchData();
  };

  const addNew = async () => {
    // if (route.params?.text) {
    //   const newItem = {
    //     id: Math.floor(Math.random() * (1000 - 7 + 1)) + 7, // tạo id
    //     value: route.params.text,
    //   };
    //   setData([...data, newItem]);
    // }

    if (route.params?.text) {
      let dataAdd = {
        value: route.params.text,
      };

      let res = await fetch(
        'https://6708715e8e86a8d9e42eecda.mockapi.io/api/job',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(dataAdd),
        }
      );
      let data = await res.json();
      fetchData();
    }
  };

  const fetchData = async () => {
    let res = await fetch(
      'https://6708715e8e86a8d9e42eecda.mockapi.io/api/job'
    );
    let json = await res.json();

    if (json) {
      setData(json);
    }
  };

  const handleDataUpdate = (data) => {
    setTextUpdate(data);
  };

  const showModalEdit = (id) => {
    setIdupdate(id)
    setShowEdit(true);
  };

  const hideModalEdit = () => {
    setShowEdit(false);

  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    addNew();
  }, [route.params?.text]);

  const Item = ({ item }) => {
    return (
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 5,
          backgroundColor: '#DEE1E678',
          borderRadius: 5,
          padding: 10,
          marginVertical: 3,
        }}>
        <TouchableOpacity>
          <Image source={check} />
        </TouchableOpacity>

        <Text>{item.value}</Text>
        <TouchableOpacity onPress={() => showModalEdit(item.id)}>
          <Image source={pen} />
        </TouchableOpacity>
        <TouchableOpacity
          style={{ backgroundColor: 'red', borderRadius: 5, padding: 10 }}
          onPress={() => remove(item.id)}>
          <Text>Delete</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const name = route.params?.name ?? '';
  return (
    <View style={styles.container}>
      <View
        style={{
          flexDirection: 'row',
          gap: 10,
          padding: 5,
          borderWidth: 1,
          width: 200,
          borderRadius: 5,
          borderColor: '#9095A0',
        }}>
        <Image source={search} />
        <TextInput value="search" />
      </View>

      <FlatList
        data={data}
        renderItem={({ item }) => <Item item={item} />}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ marginTop: 50, gap: 20 }}></FlatList>

      <TouchableOpacity
        style={{
          backgroundColor: '#00BDD6',
          width: 50,
          height: 50,
          borderRadius: '50%',
          alignItems: 'center',
          justifyContent: 'center',
        }}
        onPress={() => navigation.navigate('screen3', { name })}>
        <Text style={{ fontSize: 30, color: 'white' }}>+</Text>
      </TouchableOpacity>

      {showEdit === true && (
        <ModalEdit
          showEdit={showEdit}
          hideModalEdit={hideModalEdit}
          idUpdate={idUpdate}
          update = {update}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 8,
    alignItems: 'center',
  },
});
