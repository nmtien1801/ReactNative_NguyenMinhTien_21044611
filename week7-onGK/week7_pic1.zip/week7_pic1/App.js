import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createContext, useContext, useState } from 'react';

import Screen1 from './Screen1';
import Screen2 from './Screen2';
import Screen3 from './Screen3';

import Header from './header';

export const userContext = createContext(null) // export ra để sử dụng bên screen1

const Stack = createNativeStackNavigator();

export default function App() {
  const [user, setUser] = useState({name:''})

  return (
    <userContext.Provider value={{user, setUser}}>
     <UserProfile />
    </userContext.Provider>
  );
}

const UserProfile = () =>{
 
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="screen1">
        <Stack.Screen
          name="screen1"
          component={Screen1}
          options={{
            header: () => {},
          }}
        />
        <Stack.Screen
          name="screen2"
          component={Screen2}
          // optionS = {}
          // ({}) => ({ header: ()=> <> })
          options={({ route, navigation }) => ({
            header: () => <Header route={route} navigation={navigation} />,
          })}
        />
        <Stack.Screen
          name="screen3"
          component={Screen3}
          options={({ route, navigation }) => ({
            header: () => <Header route={route} navigation={navigation} />,
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  )
}

const styles = StyleSheet.create({});
