import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import avatar from './assets/avatar.png';
import back from './assets/back.png';
import { createContext, useContext, useState } from 'react';
import { userContext } from './App';

export default function Header({ route, navigation }) {
  // const navigation = useNavigation();
  const user = useContext(userContext);

  return (
    <View style={styles.header}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Image source={back} />
      </TouchableOpacity>
      <View style={styles.headerContent}>
        <Image source={avatar} />
        <View>
          {/*<Text style={styles.greeting}>Hi {route.params?.name ?? ''}</Text>*/}
          <Text style={styles.greeting}>Hi {user.user.name}</Text>
          <Text style={styles.subGreeting}>Have agrate day a head</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#FFFFFF',
    justifyContent: 'space-between',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 16,
    gap: 10,
  },
  greeting: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  subGreeting: {
    fontSize: 14,
    color: '#757575',
  },
});
