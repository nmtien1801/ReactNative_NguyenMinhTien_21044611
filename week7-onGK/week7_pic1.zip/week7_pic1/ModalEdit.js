import React, { useState, useEffect } from 'react';
import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  FlatList,
  Modal,
} from 'react-native';
import input from './assets/input.png';
import note from './assets/note.png';

export default function ModalEdit({ showEdit, hideModalEdit, idUpdate, update }) {
  const [textUpdate, setTextUpdate] = useState('');

  const updateParrent = () => {
    update(idUpdate, {value: textUpdate})
    hideModalEdit();
  };

  return (
    <View style={styles.container}>
      <Modal
        animationType="slide" // Hiệu ứng khi Modal xuất hiện: 'none', 'slide', hoặc 'fade'
        transparent={true} // Modal có nền trong suốt hay không
        visible={showEdit} // Điều kiện để hiện/ẩn Modal
        onRequestClose={hideModalEdit}>
        {/* Nội dung của Modal */}
        <View style={styles.modalContainer}>
          <View style={styles.modalView}>
            <TextInput
              placeholder="update your job"
              value={textUpdate}
              onChangeText={setTextUpdate}
            />

            <TouchableOpacity onPress={() => updateParrent()}>
              <Text>Update</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(232, 232,232, 0.5)', // Nền trong suốt khi Modal hiển thị
  },
  modalView: {
    width: 300,
    padding: 20,
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5, // Đổ bóng cho Modal (Android)
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});
