import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import email from './assets/email.png';
import React, { useState, useEffect, useContext } from 'react';
import { userContext } from './App';

export default function Screen1({ navigation }) {
  const { user, setUser } = useContext(userContext);
  const [name, setName] = useState(user.name);

  const handleSetName = (newName) => {
    setName(newName);
    setUser((prevUser) => ({
      ...prevUser, // Giữ nguyên các thuộc tính khác của user
      name: newName, // Cập nhật name
    }));
  };

  return (
    <View style={styles.container}>
      <View style={{ width: 100, height: 100, borderWidth: 1 }}></View>

      <View>
        <Text>MANAGE YOUR TASK</Text>
      </View>

      <View
        style={{
          flexDirection: 'row',
          gap: 10,
          justifyContent: 'center',
          alignItems: 'center',
          borderWidth: 1,
          padding: 5,
          width: 200,
        }}>
        <Image source={email} />
        <TextInput
          placeholder="Enter your name"
          style={{ color: '#9095A0' }}
          value={name}
          // onChangeText={setName}
          // value = {user?.name}
          onChangeText={handleSetName}
        />
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: '#00BDD6',
          width: 200,
          padding: 10,
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 5,
        }}
        onPress={() => navigation.navigate('screen2', { name })}>
        <Text style={{ color: 'white' }}>GET STARTED -></Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 8,
    alignItems: 'center',
    gap: 50,
  },
});
