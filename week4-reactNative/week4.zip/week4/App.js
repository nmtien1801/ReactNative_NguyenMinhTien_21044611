import { Text, View, StyleSheet, TextInput, Button } from 'react-native';
import { useState } from 'react';

export default function App() {
  const [generateNumber, setGenerateNumber] = useState('')

  const handleGenerate = (text) => {
    setGenerateNumber(text)
  }

  const handleClickCreate = () => {
    setGenerateNumber('asdsd')
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>PASSWORD GENERATOR</Text>
        <TextInput 
          style={styles.input}
          value={generateNumber}
          // onChangeText = {(text) => handleGenerate(text)}
          />
      <Button 
        title={'GENERATE PASSWORD'}  
        color = '#9966FF'
        onPress = {()=>handleClickCreate()}/>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor:"#9966FF",
    height: 400,
    padding: 20,
  },
 content:{
    backgroundColor:"#330066",
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: 360,
 },
 title:{
   color: 'white',
   fontSize: 18,
   fontWeight: 600,
 },
 input:{
   backgroundColor: '#330033',
   height: 40,
   width: 300,
   marginTop: 20,
   color: 'white'
 },
});
