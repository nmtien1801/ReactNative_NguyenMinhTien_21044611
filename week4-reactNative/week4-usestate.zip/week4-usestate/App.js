import { Text, SafeAreaView, StyleSheet, View, Button } from 'react-native';
import React, { useState } from 'react';

export default function App() {
  const [numbers, setNumbers] = useState([1, 2, 3]);

  const increase = () => {
    let _numbers = numbers.map((item) => item + 1);

    setNumbers(_numbers);
    console.log(_numbers);
  };

  return (
    <View style={{ height: 300 }}>
      <Button title="click me" onPress={() => increase()} />
    </View>
  );
}

const styles = StyleSheet.create({});
