import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  CheckBox,
} from 'react-native';

const PasswordGenerator = () => {
  const [includeLowercase, setIncludeLowercase] = useState(false);
  const [includeUppercase, setIncludeUppercase] = useState(false);
  const [includeNumbers, setIncludeNumbers] = useState(false);
  const [includeSymbols, setIncludeSymbols] = useState(false);
  const [generatedPassword, setGeneratedPassword] = useState('');

  const generatePassword = () => {
    const lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
    const uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    const specialSymbols = '!@#$%^&*()-_=+[]{}|;:,.<>?';

    const allCharacters = checkChooseCheckbox(
      lowercaseLetters,
      uppercaseLetters,
      numbers,
      specialSymbols
    );

if (!allCharacters) {
      alert('Please select at least one checkbox!');
      return;
    }

    const minLength = 8; // Độ dài tối thiểu
    const maxLength = 16; // Độ dài tối đa
    const length =
      Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;

    let password = '';

    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * allCharacters.length);
      password += allCharacters[randomIndex];
    }

    setGeneratedPassword(password);
  };

  const checkChooseCheckbox = (
    lowercaseLetters,
    uppercaseLetters,
    numbers,
    symbols
  ) => {
    let allCharacters = '';

    if (includeLowercase) {
      allCharacters += lowercaseLetters;
    }

    if (includeUppercase) {
      allCharacters += uppercaseLetters;
    }

    if (includeNumbers) {
      allCharacters += numbers;
    }

    if (includeSymbols) {
      allCharacters += symbols;
    }

    return allCharacters;
  };

  return (
    <View style={styles.container}>
      <View style={styles.main}>
        <Text style={styles.title}>PASSWORD GENERATOR</Text>

        <TextInput
          style={styles.input}
          value={generatedPassword}
          onChangeText={(value) => setGeneratedPassword(value)}
        />

        <View style={styles.optionContainer}>
          <Text style={styles.passwordLength}>Password Length:</Text>
          <Text style={styles.password}> {generatedPassword.length}</Text>
        </View>

        <View style={styles.optionContainer}>
          <Text style={{ color: 'white' }}>Include lowercase letters</Text>
          <CheckBox
            value={includeLowercase}
            onValueChange={(newValue) => {
              setIncludeLowercase(newValue);
            }}
          />
        </View>
        <View style={styles.optionContainer}>
          <Text style={{ color: 'white' }}>Include uppercase letters</Text>
          <CheckBox
            value={includeUppercase}
            onValueChange={(newValue) => {
              setIncludeUppercase(newValue);
            }}
          />
        </View>
        <View style={styles.optionContainer}>
          <Text style={{ color: 'white' }}>Include numbers</Text>
          <CheckBox
            value={includeNumbers}
            onValueChange={(newValue) => {
              setIncludeNumbers(newValue);
            }}
          />
        </View>
        <View style={styles.optionContainer}>
          <Text style={{ color: 'white' }}>Include special symbols</Text>
          <CheckBox
            value={includeSymbols}
            onValueChange={(newValue) => {
              setIncludeSymbols(newValue);
            }}
          />
        </View>

        <View style={{ marginTop: 15 }}>
          <Button
            title="GENERATE PASSWORD"
            onPress={() => generatePassword()}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#3B3B98',
  },
  main: {
    flex: 1,
    paddingHorizontal: 30,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#23235B',
    borderRadius: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  input: {
    width: '80%',
    height: 40,
    borderWidth: 1,
    borderColor: 'white',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginVertical: 10,
    color: 'white',
  },
  optionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '80%',
    marginVertical: 5,
    color: 'white',
  },
  password: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 20,
  },
  passwordLength: {
    color: 'white',
    marginTop: 10,
  },
});

export default PasswordGenerator;
