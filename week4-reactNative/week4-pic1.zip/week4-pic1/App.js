import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import avata_user from './assets/avatar_user.png';
import eye from './assets/eye.png';
import lock from './assets/lock.png';

export default function App() {
  return (
    <LinearGradient colors={['#FBCB00', '#BF9A00']} style={styles.background}>
      <View
        style={{ height: 200, justifyContent: 'center', alignItems: 'start' }}> 
        <Text style={{ fontSize: 30, fontWeight: 500 }}>LOGIN</Text>
      </View>

      <View style={{ justifyContent: 'center', gap: 20, margin: 10 }}>
        <View style={[styles.wrapInput, styles.input]}>
          <Image source={avata_user} />
          <TextInput value="Name" style={{ fontWeight: 600, fontSize: 16 }} />
        </View>

        <View style={[styles.wrapInput, styles.input]}>
          <Image source={lock} />
          <TextInput
            value="Password"
            style={{ fontWeight: 600, fontSize: 16 }}
          />
          <Image source={eye} />
        </View>
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: 'black',
          justifyContent: 'center',
          alignItems: 'center',
          margin: 10,
        }}>
        <Text style={{ color: 'white', padding: 10 }}>LOGIN</Text>
      </TouchableOpacity>

      <TouchableOpacity style={{ alignItems: 'center', marginTop: 30 }}>
        <Text style={{ fontSize: 16, fontWeight: 600 }}>
          Forgot your password?
        </Text>
      </TouchableOpacity>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: '100%',
  },
  input: {
    borderWidth: 1,
    padding: 10,
  },
  wrapInput: {
    flexDirection: 'row',
    gap: 10,
  },
});
