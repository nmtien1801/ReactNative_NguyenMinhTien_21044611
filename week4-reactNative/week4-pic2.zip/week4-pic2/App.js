import React, { useState } from 'react';
import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  TouchableOpacity,
  Image,
  TextInput,
} from 'react-native';
import usb from './assets/usb.png';
import start from './assets/Star.png';
import camera from './assets/camera.png';

export default function App() {
  const [review, setReview] = useState('');

  return (
    <SafeAreaView style={styles.container}>
      <View style={{ flexDirection: 'row', gap: 15 , width: 300}}>
        <Image source={usb} />
        <Text style={styles.textBold}>
          USB Bluetooth Music Receiver HJX-001-Biến loa thường thành loa
          bluetooth
        </Text>
      </View>

      <Text style={[styles.textBold,{marginTop: 40}]}>Cực kì hài lòng</Text>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Image source={start} />
        <Image source={start} />
        <Image source={start} />
        <Image source={start} />
        <Image source={start} />
      </View>

      <TouchableOpacity
        style={{
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          borderWidth: 1,
          paddingHorizontal: 90,
          paddingVertical: 10,
          gap: 10,
          borderRadius: 5,
          borderColor: 'blue',
        }}>
        <Image source={camera} />

        <Text>Thêm hình ảnh</Text>
      </TouchableOpacity>

<TextInput
        style={styles.reviewInput}
        multiline
        numberOfLines={8}
        placeholder="Hãy chia sẻ những điều mà bạn thích về sản phẩm"
        value={review}
        onChangeText={setReview}
      />

      <TouchableOpacity
        style={{
          backgroundColor: 'blue',
          borderRadius: 5,
          paddingHorizontal: 150,
          paddingVertical: 10
        }}>
        <Text style={{ color: 'white', fontWeight: 600, fontSize: 15 }}>
          Gửi
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 8,
    gap: 20,
  },
  reviewInput: {
    borderWidth: 1,
    borderColor: '#D3D3D3',
    borderRadius: 4,
    padding:8,
    width: 320,
    marginBottom: 16,

  },

  textBold:{
    fontSize: 16,
    fontWeight: 600
  },
});
