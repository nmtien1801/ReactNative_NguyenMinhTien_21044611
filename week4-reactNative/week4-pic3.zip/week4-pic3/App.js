import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import book from './assets/book.png';

export default function BookListing() {
  const [quantity, setQuantity] = useState(1);
  const [discountCode, setDiscountCode] = useState('');

  const incrementQuantity = () => setQuantity((prev) => prev + 1);
  const decrementQuantity = () => setQuantity((prev) => Math.max(1, prev - 1));

  return (
    <View style={styles.container}>
      <View style={styles.productInfo}>
        <Image source={book} style={styles.bookCover} />
        <View style={styles.details}>
          <Text style={styles.title}>
            Nguyên hàm tích phân và ứng dụng cung cấp bởi Tiki Trading
          </Text>

          <Text style={styles.price}>141.800 đ</Text>
          <Text style={styles.originalPrice}>141.000 đ</Text>

          <View style={styles.quantityContainer}>
            <TouchableOpacity
              onPress={decrementQuantity}
              style={styles.quantityButton}>
              <Text style={styles.quantityButtonText}>-</Text>
            </TouchableOpacity>
            <TextInput
              style={styles.quantityInput}
              value={quantity.toString()}
              onChangeText={(text) =>
                setQuantity(Math.max(1, parseInt(text) || 1))
              }
              keyboardType="numeric"
            />
            <TouchableOpacity
              onPress={incrementQuantity}
              style={styles.quantityButton}>
              <Text style={styles.quantityButtonText}>+</Text>
            </TouchableOpacity>
            <TouchableOpacity>
              <Text style={styles.buyLater}>Mua sau</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <View style={styles.seeMore}>
        <Text style={styles.savedDiscount}>Mã giảm giá đã lưu</Text>

        <TouchableOpacity>
          <Text style={styles.viewHere}>Xem tại đây</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.discountContainer}>
        <TextInput
          style={styles.discountInput}
          placeholder="Mã giảm giá"
          value={discountCode}
          onChangeText={setDiscountCode}
        />
        <TouchableOpacity style={styles.applyButton}>
          <Text style={styles.applyButtonText}>Áp dụng</Text>
        </TouchableOpacity>
      </View>

      <View style={[styles.provisional, styles.topColor]}>
        <Text style={{ fontSize: 14, fontWeight: 600 }}>
          Bạn có phiếu quà tặng Tiki/ Got it/ Urbox?
        </Text>
        <TouchableOpacity style={styles.viewHere}>
          Nhập tại đây
        </TouchableOpacity>
      </View>

      <View style={[styles.provisional, styles.topColor]}>
        <Text style={{ fontSize: 20, fontWeight: 600 }}>Tạm tính</Text>
        <Text style={styles.price}>141.800 đ</Text>
      </View>

      <View>
        <View
          style={[styles.provisional, styles.topColor, { borderTopWidth: 80 }]}>
          <Text style={{ fontSize: 20, fontWeight: 600, color: '#808080' }}>
            Thành tiền
          </Text>
          <Text style={styles.price}>141.800 đ</Text>
        </View>

        <TouchableOpacity
          style={{
            backgroundColor: 'red',
            height: 40,
            borderRadius: 5,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{ fontWeight: 450, fontSize: 20, color: 'white' }}>
            Tiến hành đặt hàng
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  productInfo: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  bookCover: {
    width: 104,
    height: 158,
    resizeMode: 'cover',
    marginRight: 16,
  },
  details: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  price: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ee4d2d',
    marginBottom: 2,
    marginVertical: 10,
  },
  originalPrice: {
    fontSize: 14,
    color: '#999',
    textDecorationLine: 'line-through',
    marginVertical: 10,
  },
  seeMore: {
    flexDirection: 'row',
    gap: 30,
    marginBottom: 30,
  },
  provisional: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  quantityButton: {
    width: 30,
    height: 30,
    borderWidth: 1,
    borderColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantityButtonText: {
    fontSize: 18,
    color: '#333',
  },
  topColor: {
    borderTopWidth: 20,
    borderTopColor: '#C4C4C4',
  },
  quantityInput: {
    width: 40,
    height: 30,
    borderWidth: 1,
    borderColor: '#ccc',
    textAlign: 'center',
    marginHorizontal: 8,
  },
  buyLater: {
    marginLeft: 16,
    color: '#1a9cb7',
    fontWeight: 'bold',
  },
  viewHere: {
    color: '#1a9cb7',
    marginBottom: 8,
  },
  savedDiscount: {
    fontWeight: 'bold',
    marginBottom: 8,
  },
  discountContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  discountInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    paddingHorizontal: 8,
    marginRight: 8,
  },
  applyButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#1a9cb7',
    paddingHorizontal: 16,
    paddingVertical: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  applyButtonText: {
    color: '#1a9cb7',
    fontWeight: 'bold',
  },
});
