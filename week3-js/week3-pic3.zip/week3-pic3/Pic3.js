import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import lock from './assets/lock.png';
import mail from './assets/mail.png';
import pic4 from './Pic4'

export default function Pic3({navigation}) {
  return (
    <LinearGradient
      colors={['#C7F4F6', '#D1F4F6', '#E5F4F5', '#00CCF9']}
      style={[styles.background, styles.container]}>
      <Image source={lock} />
      <Text style={{ fontSize: 22, fontWeight: 600 }}>FORGET PASSWORD</Text>

      <View style={{ marginTop: 20 , width: 300}}>
        <Text style={{ fontSize: 13, fontWeight: 600}}>
          Provide your account’s email for which you want to reset your password
        </Text>
      </View>

      <View style={{ backgroundColor: '#C4C4C4', flexDirection: 'row' , width: 300, marginTop: 20}}>
        <Image source={mail} />
        <TextInput value="Email"></TextInput>
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: '#E3C000',
          width: 300,
          padding: 10,
          marginTop: 30,
          justifyContent: 'center',
          alignItems:'center'
        }}
        onPress={()=>navigation.navigate('pic4')}
        >
        <Text style={{ fontSize: 13, fontWeight: 600}}>NEXT</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 20,
  },
  background: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: '100%',
  },
});
