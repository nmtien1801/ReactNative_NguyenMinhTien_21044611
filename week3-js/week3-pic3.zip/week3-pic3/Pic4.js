import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import lock from './assets/lock.png';
import mail from './assets/mail.png';

export default function Pic4({ navigation }) {
  return (
    <LinearGradient
      colors={['#C7F4F6', '#D1F4F6', '#E5F4F5', '#00CCF9']}
      style={[styles.background, styles.container]}>
      <View style={{fontWeight: 600, fontSize: 50}}>CODE</View>
      <View style={{fontWeight: 600, fontSize: 18, marginVertical: 30}}>VERIFICATION</View>
      <View>
        <Text style={{fontWeight: 600, fontSize: 15}}>Enter ontime password sent on</Text>
        <Text style={{fontWeight: 600, fontSize: 15}}>++849092605798</Text>
      </View>

      <View style={{ flexDirection: 'row' }}>
        <View style={styles.square}></View>
        <View style={styles.square}></View>
        <View style={styles.square}></View>
        <View style={styles.square}></View>
        <View style={styles.square}></View>
        <View style={styles.square}></View>
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: '#E3C000',
          padding: 14,
          width: 300,
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: 20,
        }}>
        <Text style={{fontWeight: 600, fontSize: 18}}>VERIFY CODE</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 20,
  },
  background: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: '100%',
  },
  square: {
    borderColor: 'black',
    borderWidth: 2,
    width: 50,
    height: 50,
  },
});
