import {
  Text,
  SafeAreaView,
  StyleSheet,
  Image,
  View,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import eye from './assets/eye.png';
import ortherLogin from './assets/OtherLogin.png';
import fb from './assets/fb.png';
import gg from './assets/gg.png';
import zalo from './assets/zalo.png';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={{fontSize: 30, fontWeight: 600}}>LOGIN</Text>

      <View>
        <View style={[styles.input, { height: 38 }]}>
          <TextInput value="Email" />
        </View>
        <View style={styles.input}>
          <TextInput value="Password" />
          <Image source={eye} />
        </View>
      </View>

      <TouchableOpacity
        style={{
          backgroundColor: 'red',
          width: 300,
          height: 40,
          justifyContent: 'center',
          alignItems: 'center',
          marginTop: 30,
          borderRadius: 5,

        }}>
        <Text style={{fontSize: 15,color: 'white', fontWeight: 600}}>LOGIN</Text>
      </TouchableOpacity>

      <Text style={{fontSize: 15, marginTop: 15}}>When you agree to terms and conditions</Text>
      <Text style={{fontSize: 15, marginTop: 15, color: '#5D25FA'}}>For got your password?</Text>
      <Text style={{fontSize: 15, marginTop: 15, fontWeight: 600}}>Or login with</Text>

      <View>
        <View style={{ flexDirection: 'row', marginTop: 30 }}>
          <View
            style={{
              backgroundColor: '#25479B',
              width: 100,
              height: 40,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image source={fb} />
          </View>
          <View
            style={{
              backgroundColor: '#0F8EE0',
              width: 100,
              height: 40,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image source={zalo} />
          </View>
          <View
            style={{
              backgroundColor: '#FFFFFF',
              width: 100,
              height: 40,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image source={gg} />
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#31AA5230',
    padding: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    borderWidth: 1,
    flexDirection: 'row',
    marginTop: 30,
    justifyContent:'space-between',
    backgroundColor: '#C4C4C44D',
    paddingHorizontal: 10,
    width: 300,
  },
});
