import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  Image,
  FlatList,
  TouchableOpacity,
  Button,
} from "react-native";
import React, { useState, useEffect } from "react";

const randomDiceRoll = () => {
  return Math.floor(Math.random() * 6) + 1;
};

const calculateInitialValue = () => {
  console.log("calculateInitialValue");
  return Math.floor(Math.random() * 100);
};

export default function App() {
  const [count, setCount] = useState(0);
  const [diceRoll, setDiceRoll] = useState([]);
  const [count2, setCount2] = useState(() => calculateInitialValue());

  return (
    <View style={styles.container}>
      <View styles={{ padding: 20 }}>
        <Text>Count: {count}</Text>
        <Button title="Increase" onPress={() => setCount(count + 1)} />
        <Button title="Reset" onPress={() => setCount(0)} />
       
      </View>

      <View>
        <Button
          title="Roll dice!"
          onPress={() => {
            setDiceRoll([...diceRoll, randomDiceRoll()]);
          }}
        />
        {diceRoll.map((diceRoll, index) => (
          <Text key={index} style={{ fontSize: 24 }}>
            {diceRoll}
          </Text>
        ))}
      </View>

      <View styles={{ padding: 20 }}>
        <Text>Count: {count2}</Text>
        <Button title="Increase" onPress={() => setCount2(count2 + 1)} />
        <Button
          title="Reset2"
          onPress={() => setCount2(() => calculateInitialValue())}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    gap: 50,
  },
});
