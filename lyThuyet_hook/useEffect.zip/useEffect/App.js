import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  Image,
  FlatList,
  TouchableOpacity,
  TextInput,
  Button,
} from "react-native";
import React, { useState, useEffect } from "react";

export default function App() {
  const [count, setCount] = useState(0);
  const countEvery3 = Math.floor(count / 3);

  useEffect(() => {
    console.log("countEvery3: ",countEvery3);
  });

  useEffect(() => {
    console.log("count has changed: ", count);
    return () => {
      console.log("clean up");
    };
  }, [count]);

  return (
    <View style={styles.container}>
      <Button
        title={`Decrement ${count}`}
        onPress={() => {
          setCount(count - 1);
        }}
      />

      <Text
        onPress={() => {
          setCount(count + 1);
        }}
      >
        Increment Count: {count}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection:'row',
    justifyContent: "center",
    backgroundColor: "#ecf0f1",
    padding: 8,
    gap: 50
  },
});
