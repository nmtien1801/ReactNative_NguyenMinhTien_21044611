import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  Image,
  FlatList,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import React, { useState, useEffect } from 'react';

import back from './assets/icon/back.png';
import bi_cart_check from './assets/icon/bi_cart-check.png';
import dots from './assets/icon/dots.png';
import search from './assets/icon/search.png';
import stroke from './assets/icon/stroke.png';
import menu from './assets/icon/menu.png';
import home from './assets/icon/home.png';
import star from './assets/icon/star.png';

import carbusbtops2 from './assets/image/carbusbtops2.png';
import daucam from './assets/image/daucam.png';
import dauchuyendoi from './assets/image/dauchuyendoi.png';
import dauchuyendoipsps2 from './assets/image/dauchuyendoipsps2.png';
import daynguon from './assets/image/daynguon.png';
import giacchuyen from './assets/image/giacchuyen.png';

const products = [
  {
    id: '1',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: carbusbtops2,
    discount: '30%',
  },
  {
    id: '2',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: daucam,
    discount: '30%',
  },
  {
    id: '3',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: dauchuyendoi,
    discount: '30%',
  },
  {
    id: '4',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: dauchuyendoipsps2,
    discount: '30%',
  },
  {
    id: '5',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: daynguon,
    discount: '30%',
  },
  {
    id: '6',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: giacchuyen,
    discount: '30%',
  },
  {
    id: '7',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: giacchuyen,
    discount: '30%',
  },
  {
    id: '8',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: giacchuyen,
    discount: '30%',
  },
  {
    id: '9',
    title: 'Cáp chuyển từ Cổng USB sang PS2...',
    price: '69.900 đ',
    rating: star,
    image: giacchuyen,
    discount: '30%',
  },
];

const ProductItem = ({ item }) => (
  <View style={styles.item}>
    <Image source={item.image} style={{ height: 90 }} />
    <Text style={{ fontSize: 13 , fontWeight: 600}}>{item.title}</Text>
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Image source={item.rating} />
      <Text style={{ fontSize: 13 , fontWeight: 600}}>(15)</Text>
    </View>
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 30,
      }}>
      <Text style={{ fontSize: 13 , fontWeight: 600}}>{item.price}</Text>
      <Text style={{color: '#969DAA'}}>{item.discount}</Text>
    </View>
  </View>
);

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.flex}>
        <Image source={back} />
        <View
          style={{
            backgroundColor: 'white',
            flexDirection: 'row',
            gap: 10,
            paddingVertical: 3,
            paddingLeft: 10,
          }}>
          <Image source={search} />
          <TextInput style={{ color: '#7D5B5B' }} placeholder="dây cáp usb" />
        </View>

        <Image source={bi_cart_check} />
        <Image source={dots} />
      </View>

      <FlatList
        data={products}
        renderItem={({ item }) => <ProductItem item={item} />}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.content}
      />

      <View style={styles.flex}>
        <Image source={menu} />
        <Image source={home} />
        <Image source={stroke} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  flex: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1BA9FF',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  content: {
    flex: 1,
    alignItems: 'center',
  },
  item:{
    gap: 5,
    padding: 15,
  }
});
