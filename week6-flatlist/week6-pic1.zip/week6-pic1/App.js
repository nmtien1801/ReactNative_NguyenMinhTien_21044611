import {
  Text,
  SafeAreaView,
  StyleSheet,
  View,
  Image,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import React, { useState, useEffect } from 'react';
import stroke from './assets/Stroke.png';
import menu from './assets/menu.png';
import back from './assets/back.png';
import cart from './assets/cart.png';
import home from './assets/home.png';

import ca_nau_lau from './assets/imgProduct/ca_nau_lau.png';
import ga_bo_toi from './assets/imgProduct/ga_bo_toi.png';
import do_choi_dang_mo_hinh from './assets/imgProduct/do_choi_dang_mo_hinh.png';
import xa_can_cau from './assets/imgProduct/xa_can_cau.png';
import lanh_dao_gian_don from './assets/imgProduct/lanh_dao_gian_don.png';
import hieu_long_con_tre from './assets/imgProduct/hieu_long_con_tre.png';

const DATA = [
  {
    id: '1',
    title: 'ca nấu lẩu nấu mì mini...',
    des: 'shop devang',
    image: ca_nau_lau,
  },
  {
    id: '2',
    title: '1kg khô gà bơ tỏi...',
    des: 'shop devang',
    image: ga_bo_toi,
  },
  {
    id: '3',
    title: 'đồ chơi dạng mô hình',
    des: 'shop LTDfood',
    image: do_choi_dang_mo_hinh,
  },
  {
    id: '4',
    title: 'xe cần cẩu đa năng',
    des: 'shop thế giới đồ chơi',
    image: xa_can_cau,
  },
  {
    id: '5',
    title: 'lãnh đạo giản đơn',
    des: 'minh long book',
    image: lanh_dao_gian_don,
  },
  {
    id: '6',
    title: 'hiểu lòng con trẻ',
    des: 'minh long book',
    image: hieu_long_con_tre,
  },
  {
    id: '7',
    title: 'hiểu lòng con trẻ',
    des: 'minh long book',
    image: hieu_long_con_tre,
  },
  {
    id: '8',
    title: 'hiểu lòng con trẻ',
    des: 'minh long book',
    image: hieu_long_con_tre,
  },
];

const Item = ({ item }) => (
  <View style={styles.item}>
    <Image source={item.image} />
    <Text style={styles.title}>{item.title}</Text>
    <TouchableOpacity
      style={{
        backgroundColor: 'red',
        padding: 10,
        marginRight: 10,
        height: 40,
        width: 70,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <Text style={{ color: 'white', fontSize: 15, fontWeight: 500 }}>
        Chat
      </Text>
    </TouchableOpacity>
  </View>
);

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.flex}>
        <Image source={back} />
        <Text style={{ color: 'white', fontSize: 15, fontWeight: 500 }}>
          Chat
        </Text>
        <Image source={cart} />
      </View>

      <View style={styles.content}>
        <Text style={{ paddingHorizontal: 20 }}>
          Bạn có thắc mắc gì với sản phẩm vừa xem. Đừng ngại chat với shop!
        </Text>
        <FlatList
          data={DATA}
          renderItem={({ item }) => <Item item={item} />}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ gap: 10 }}
        />
      </View>

      <View style={styles.flex}>
        <Image source={menu} />
        <Image source={home} />
        <Image source={stroke} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  flex: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1BA9FF',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },

  content: {
    flex: 1,
  },

  item: {
    flexDirection: 'row',
    paddingTop: 10,
    justifyContent: 'space-between'
  },
  title: {
    paddingVertical: 10,
  },
});
